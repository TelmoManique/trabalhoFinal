package com.telmomanique.trabalhofinal.TheLanguageFinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheLanguageFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheLanguageFinderApplication.class, args);
	}

}
