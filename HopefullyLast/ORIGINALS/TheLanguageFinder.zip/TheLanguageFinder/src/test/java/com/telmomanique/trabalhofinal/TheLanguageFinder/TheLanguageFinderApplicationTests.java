package com.telmomanique.trabalhofinal.TheLanguageFinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheLanguageFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
