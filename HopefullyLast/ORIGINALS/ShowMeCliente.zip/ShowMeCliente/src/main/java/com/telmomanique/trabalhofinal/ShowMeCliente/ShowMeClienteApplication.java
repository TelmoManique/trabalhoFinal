package com.telmomanique.trabalhofinal.ShowMeCliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShowMeClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShowMeClienteApplication.class, args);
	}

}
